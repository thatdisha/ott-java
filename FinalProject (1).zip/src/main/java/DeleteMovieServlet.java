import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

@WebServlet("/DeleteMovieServlet")
public class DeleteMovieServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String movieId = request.getParameter("id");

        if (movieId != null) {
            String DB_URL = "jdbc:mysql://localhost:3306/java";
            String DB_USER = "root";
            String DB_PASS = "";
            boolean success = false;

            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
                PreparedStatement stmt = conn.prepareStatement("DELETE FROM movies WHERE id = ?");
                stmt.setInt(1, Integer.parseInt(movieId));
                int rowsAffected = stmt.executeUpdate();
                
                if (rowsAffected > 0) {
                    success = true;
                }

                stmt.close();
                conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }

            if (success) {
                response.sendRedirect("managecontent.jsp?message=Movie deleted successfully");
            } else {
                response.sendRedirect("managecontent.jsp?message=Failed to delete movie");
            }
        } else {
            response.sendRedirect("managecontent.jsp?message=Movie ID is missing");
        }
    }
}
