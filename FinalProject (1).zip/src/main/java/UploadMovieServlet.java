import java.io.*;
import java.nio.file.Files;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.nio.charset.StandardCharsets; 
@WebServlet("/UploadMovieServlet")
public class UploadMovieServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String SAVE_DIR = "uploads";
    private static final String DB_URL = "jdbc:mysql://localhost:3306/java";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        String contentType = request.getHeader("Content-Type");
        if (contentType == null || !contentType.contains("multipart/form-data")) {
            response.getWriter().println("Invalid content type.");
            return;
        }

        String boundary = contentType.split("boundary=")[1];
        boundary = "--" + boundary;

        InputStream inputStream = request.getInputStream();
        byte[] bodyBytes = inputStream.readAllBytes();
        String body = new String(bodyBytes, "ISO-8859-1");

        String title = null, category = null, description = null;
        String videoFileName = null, imageFileName = null;
        byte[] videoBytes = null, imageBytes = null;

        String[] parts = body.split(boundary);

        for (String part : parts) {
            if (part.contains("name=\"title\"")) {
                title = extractTextValue(part);
            } else if (part.contains("name=\"category\"")) {
                category = extractTextValue(part);
            } else if (part.contains("name=\"description\"")) {
                description = extractTextValue(part);
            } else if (part.contains("name=\"video\"") && part.contains("filename=\"")) {
                videoFileName = System.currentTimeMillis() + "_" + extractFilename(part);
                videoBytes = extractFileBytes(part, bodyBytes);
            } else if (part.contains("name=\"image\"") && part.contains("filename=\"")) {
                imageFileName = System.currentTimeMillis() + "_" + extractFilename(part);
                imageBytes = extractFileBytes(part, bodyBytes);
            }
        }

        if (title == null || category == null || description == null ||
            videoFileName == null || videoBytes == null ||
            imageFileName == null || imageBytes == null) {
            response.getWriter().println("Missing data.");
            return;
        }

        String uploadPath = getServletContext().getRealPath("") + File.separator + SAVE_DIR;
        File uploadDir = new File(uploadPath);
        if (!uploadDir.exists()) uploadDir.mkdirs();

        // Save files
        Files.write(new File(uploadDir, videoFileName).toPath(), videoBytes);
        Files.write(new File(uploadDir, imageFileName).toPath(), imageBytes);

        String videoPath = SAVE_DIR + "/" + videoFileName;
        String imagePath = SAVE_DIR + "/" + imageFileName;

        // Store in DB
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO movies (title, category, description, path, image) VALUES (?, ?, ?, ?, ?)"
            );
            stmt.setString(1, title);
            stmt.setString(2, category);
            stmt.setString(3, description);
            stmt.setString(4, videoPath);
            stmt.setString(5, imagePath);
            stmt.executeUpdate();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("DB Error: " + e.getMessage());
            return;
        }

        response.sendRedirect("AdminPage.jsp?message=Movie added successfully");
    }

    private String extractTextValue(String part) {
        int start = part.indexOf("\r\n\r\n") + 4;
        int end = part.lastIndexOf("\r\n");
        return part.substring(start, end).trim();
    }

    private String extractFilename(String part) {
        int start = part.indexOf("filename=\"") + 10;
        int end = part.indexOf("\"", start);
        return part.substring(start, end);
    }

    private byte[] extractFileBytes(String part, byte[] fullBody) {
        int start = part.indexOf("\r\n\r\n") + 4;
        int end = part.lastIndexOf("\r\n");
        String pre = part.substring(0, start);
        int offset = 0;
		try {
			offset = new String(fullBody, "ISO-8859-1").indexOf(pre) + start;
	        return Arrays.copyOfRange(fullBody, offset, offset + (end - start));

		} catch (UnsupportedEncodingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        return Arrays.copyOfRange(fullBody, offset, offset + (end - start));
    }
}
