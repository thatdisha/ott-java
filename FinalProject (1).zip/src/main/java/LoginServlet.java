
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Cookie;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@WebServlet("/Login")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        try {
        	
        	//AdminLogin 
            if (email.equals("admin@mail.com") && password.equals("admin007")) {
                HttpSession session = request.getSession();
                session.setAttribute("username", "Admin");
                session.setAttribute("email", email);

                Cookie userCookie = new Cookie("username", "Admin");
                Cookie emailCookie = new Cookie("email", email);
                userCookie.setMaxAge(30 * 60);
                emailCookie.setMaxAge(30 * 60);
                response.addCookie(userCookie);
                response.addCookie(emailCookie);

                response.sendRedirect("AdminPage.jsp"); // redirect admin
                return;
            }
        	
            // Load MySQL JDBC Driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Database connection
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java", "root", "");

            // SQL query to check credentials
            String sql = "SELECT * FROM users WHERE email = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, email);
            stmt.setString(2, password);
 
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                String username = rs.getString("username"); // Get username from DB

                // Store username and email in session
                HttpSession session = request.getSession();
                session.setAttribute("username", username);
                session.setAttribute("email", email);

                // Create cookies for username and email (expires in 30 minutes)
                Cookie userCookie = new Cookie("username", username);
                Cookie emailCookie = new Cookie("email", email);
                
                userCookie.setMaxAge(30 * 60); // 30 minutes
                emailCookie.setMaxAge(30 * 60);

                response.addCookie(userCookie);
                response.addCookie(emailCookie);

                response.sendRedirect("index.jsp"); // Redirect to user page
            } else {
                response.sendRedirect("login.jsp?error=Invalid email or password");
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("login.jsp?error=DatabaseConnectionFailed");
        }
    }
}
