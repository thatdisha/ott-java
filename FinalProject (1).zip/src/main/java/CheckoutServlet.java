import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.*;

@WebServlet("/CheckoutServlet")
public class CheckoutServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Retrieve session data
        HttpSession session = request.getSession();
        String email = (String) session.getAttribute("email");
        String username = (String) session.getAttribute("username");

        if (email == null || username == null) {
            response.sendRedirect("login.jsp?error=SessionExpired");
            return;
        }

        try {
            // Connect to DB
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java", "root", "");

            // Check if user already exists in premiumusers
            String checkSql = "SELECT * FROM premiumusers WHERE email = ?";
            PreparedStatement checkStmt = conn.prepareStatement(checkSql);
            checkStmt.setString(1, email);
            ResultSet rs = checkStmt.executeQuery();

            if (!rs.next()) {
                // Insert into premiumusers
                String insertSql = "INSERT INTO premiumusers (username, email) VALUES (?, ?)";
                PreparedStatement insertStmt = conn.prepareStatement(insertSql);
                insertStmt.setString(1, username);
                insertStmt.setString(2, email);
                insertStmt.executeUpdate();
                insertStmt.close();
            }
            else {
            	 rs.close();
            	    checkStmt.close();
            	    conn.close();
            	    PrintWriter out = response.getWriter();
            	    out.println("<script type='text/javascript'>");
            	    out.println("alert('You are already a premium member!');");
            	    out.println("window.location.href = 'premium-movies.jsp';");
            	    out.println("</script>");
            	    return;
            	    
            	
            }
            
            

            rs.close();
            checkStmt.close();
            conn.close();

            // Redirect to payment confirmation or success page
            response.sendRedirect("payment.jsp");

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("checkout.jsp?error=DBError");
        }
    }
}
