import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.sql.*;

@WebServlet("/DeleteUser")
public class DeleteUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String userId = request.getParameter("userId");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java", "root", "");

            String sql = "DELETE FROM users WHERE id = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, Integer.parseInt(userId));

            int rowsAffected = stmt.executeUpdate();
            conn.close();

            if (rowsAffected > 0) {
                response.sendRedirect("manageuser.jsp"); // Refresh the page after deletion
            } else {
                response.sendRedirect("manageuser.jsp?error=UserNotFound");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("ManageUsers.jsp?error=DatabaseError");
        }
    }
}
