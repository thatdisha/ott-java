import jakarta.servlet.ServletConfig;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

@WebServlet("/DBconnection")
public class DBconnection extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Database credentials
    private static final String URL = "jdbc:mysql://localhost:3306/java";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public DBconnection() {
        super();
    }

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();

        try {
            
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Connect to MySQL
            Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);

            if (conn != null) {
                out.println("<h3>✅ Database Connection Successful!</h3>");
                conn.close(); // Close connection after testing
            } else {
                out.println("<h3>❌ Failed to connect to database.</h3>");
            }
        } catch (ClassNotFoundException e) {
            out.println("<h3>❌ JDBC Driver not found.</h3>");
            e.printStackTrace();
        } catch (SQLException e) {
            out.println("<h3>❌ SQL Error: " + e.getMessage() + "</h3>");
            e.printStackTrace();
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
