import java.io.*;
import java.sql.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

@WebServlet("/ViewMovieServlet")
public class ViewMovieServlet extends HttpServlet {
    private static final String DB_URL = "jdbc:mysql://localhost:3306/java";
    private static final String DB_USER = "root";
    private static final String DB_PASS = "";
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String movieTitle = request.getParameter("title");
        
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASS);
            PreparedStatement stmt = conn.prepareStatement("SELECT * FROM movies WHERE title = ?");
            stmt.setString(1, movieTitle);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                // Set the attributes we have in the database
                request.setAttribute("title", rs.getString("title"));
                request.setAttribute("path", rs.getString("path"));
                
                // Default values for missing attributes
                request.setAttribute("desc", "An uploaded movie by a PlayVia user.");
                request.setAttribute("image", "images/uploaded-movie.jpg");
                
                // Forward to the JSP page
                request.getRequestDispatcher("movie-player.jsp").forward(request, response);
            } else {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Movie not found");
            }
            
            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Database error");
        }
    }
}